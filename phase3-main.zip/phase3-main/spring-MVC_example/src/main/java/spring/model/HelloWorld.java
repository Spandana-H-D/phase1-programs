package spring.model;

public class HelloWorld {
	private String message;
	private String dateTime;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDataTime() {
		return dateTime;
	}
	public void setDataTime(String dataTime) {
		this.dateTime = dataTime;
	
	}
	public void setDateTime(String string) {
		// TODO Auto-generated method stub
		
	}

}
