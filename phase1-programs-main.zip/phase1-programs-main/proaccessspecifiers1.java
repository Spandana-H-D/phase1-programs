package pack1;
//3. using protected access specifiers
public class proaccessspecifiers1 {

	public void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}


