package pack2;
import pack1.*;

import pack1.pubaccessspecifiers;
public class pubaccessspecifier {

		//create another package
	

			public static void main(String[] args) {
				
				pubaccessspecifiers obj = new pubaccessspecifiers(); 
		        obj.display();  
				
			}
		}