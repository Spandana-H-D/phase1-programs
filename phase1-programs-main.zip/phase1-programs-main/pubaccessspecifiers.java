package pack1;

public class pubaccessspecifiers {
	
		//4. using public access specifiers
		
			public void display() 
		    { 
		        System.out.println("This is Public Access Specifiers"); 
		    } 
		}


