package pack2;
import pack1.*;
import pack1.proaccessspecifiers1;

		public class proaccessspecifiers extends proaccessspecifiers {

			public static void main(String[] args) {
				proaccessspecifiers obj = new proaccessspecifiers ();   
			       obj.display();  
			}

		}

	


