package pack2;
import pack1.*;

import pack1.pubaccessspecifiers;
public class accessSpecifiers4 {

		//create another package
	

			public static void main(String[] args) {
				
				pubaccessspecifiers obj = new pubaccessspecifiers(); 
		        obj.display();  
				
			}
		}
