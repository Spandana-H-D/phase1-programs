package pack2;
import pack1.*;

import pack1.proaccessspecifiers1;
public class accessSpecifiers3 extends proaccessspecifiers{
		public static void main(String[] args) {
				
				proaccessspecifiers1 obj = new proaccessspecifiers1(); 
		        obj.display();  
				
			}
		}

	

